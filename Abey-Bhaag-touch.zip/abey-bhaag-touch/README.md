# Abey Bhaag! — APK game starter

Original endless-runner/chase concept: fans chase the player; collect coins, unlock characters, use power-ups, complete missions, and visit the shop.

Character prices:
- Adrien — Free
- Doraemon — 500 coins
- MrBeast — 1,000 coins
- Ronaldo — 2,000 coins
- Ducky Bhai — 10,000 coins

This package is the first playable UI/prototype. It is not yet a compiled Android APK. The next production steps are native Android/game-engine implementation, real 3D character assets/animations, touch lane controls, collision/game-over logic, persistent save data, audio, and Android signing/build configuration.

Note: named real people and copyrighted characters require appropriate rights/licensing for public commercial release.
